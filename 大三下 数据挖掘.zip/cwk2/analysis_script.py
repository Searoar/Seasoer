# -*- coding: utf-8 -*-
import os
import re
import warnings
import jieba
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score, StratifiedKFold, train_test_split
from sklearn.metrics import f1_score, confusion_matrix
from sklearn.decomposition import LatentDirichletAllocation
from wordcloud import WordCloud
from snownlp import SnowNLP

# 过滤无关警告
warnings.filterwarnings("ignore", message="CropBox missing from /Page, defaulting to MediaBox")
warnings.filterwarnings("ignore", category=UserWarning, module="snownlp")

# ------------------------
# 中文字体配置
# ------------------------
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
plt.rcParams['axes.unicode_minus'] = False
plt.style.use('ggplot')  # 使用内置样式

# ------------------------
# 路径配置
# ------------------------
DATA_DIR = 'data'
NOVEL_DIR = os.path.join(DATA_DIR, 'novel')
SCRIPT_DIR = os.path.join(DATA_DIR, 'script')
SEGMENTED_DATA_DIR = os.path.join(DATA_DIR, 'segmented_data')
STOPWORDS_FILE = 'stopwords.txt'
FIGURES_DIR = 'figures'


# ------------------------
# 数据加载与预处理
# ------------------------
def load_data(data_path):
    """加载并解析多种格式文件"""
    if not os.path.exists(data_path):
        print(f"错误: 目录 '{data_path}' 不存在")
        return pd.DataFrame()

    data = []
    for file in os.listdir(data_path):
        file_path = os.path.join(data_path, file)
        content = ""

        try:
            if file.endswith('.txt'):
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read().strip()
            elif file.endswith('.pdf'):
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    import pdfplumber
                    with pdfplumber.open(file_path) as pdf:
                        content = "\n".join([page.extract_text().strip() for page in pdf.pages if page.extract_text()])
            elif file.endswith('.docx'):
                import docx
                doc = docx.Document(file_path)
                content = "\n".join([para.text.strip() for para in doc.paragraphs if para.text.strip()])
            else:
                print(f"跳过不支持的文件格式: {file}")
                continue

            if not content:
                print(f"警告: {file} 内容为空，已跳过")
                continue

            # 提取剧集名称（改进版）
            series_name = extract_series_name(file)

            category = '小说' if '小说' in file.lower() or '原著' in file.lower() else '剧本'
            data.append({
                'file': file,
                'content': content,
                'category': category,
                'series': series_name
            })
        except Exception as e:
            print(f"解析 {file} 失败: {str(e)}")
            continue

    return pd.DataFrame(data)


def extract_series_name(filename):
    """从文件名中提取剧集名称（改进版）"""
    # 去除扩展名
    name = os.path.splitext(filename)[0]

    # 处理分割后的文件，如"卡拉马佐夫兄弟 小说1"
    # 先移除"小说"或"剧本"标识及后面的数字
    name = re.sub(r'(小说|剧本)\d+', '', name).strip()

    # 去除"剧本"、"原著"、"小说"等关键词
    for keyword in ['剧本', '原著', '小说', 'script', 'novel']:
        name = name.replace(keyword, '').strip()

    # 处理可能存在的数字前缀（如"1.卡拉马佐夫兄弟"）
    name = re.sub(r'^\d+\.', '', name).strip()

    return name


def load_stopwords(file_path):
    """加载停用词，支持空文件"""
    if not os.path.exists(file_path):
        print(f"警告: 停用词文件 '{file_path}' 不存在，使用默认停用词")
        return list(
            ['的', '了', '在', '是', '我', '有', '和', '就', '不', '人', '都', '一', '一个', '上', '也', '很', '到',
             '说', '要', '去', '你', '会', '着', '没有', '看', '好', '自己', '这', '哈哈哈', '嘿嘿', '呵', '呸', '哎',
             '哦', '嗯']
        )

    with open(file_path, 'r', encoding='utf-8') as f:
        return [line.strip() for line in f if line.strip()]


def preprocess_text(text, stopwords):
    """文本预处理：清洗、分词、去停用词、过滤标签关键词"""
    if not isinstance(text, str) or len(text) < 10:
        return ""

    # 新增：过滤可能包含标签的关键词（如“小说”“剧本”“第X章”等）
    text = re.sub(r'\b(小说|剧本|原著|第\d+章|第\d+集|幕|场|唱段|台词|旁白|音乐剧|歌剧|话剧)\b', '', text)

    # 去除特殊字符
    text = re.sub(r'[^\w\s]', '', text)
    # 分词
    words = jieba.cut(text)
    # 过滤停用词和单字符
    words = [word for word in words if word not in stopwords and len(word) > 1]
    return " ".join(words)


# ------------------------
# 文本分割功能
# ------------------------
def segment_texts(novel_data, script_data, num_segments=10):
    """
    将每个小说和剧本平均分为多个部分并保存
    返回分割后的数据集
    """
    print(f"正在将文本分割为每个 {num_segments} 个部分...")

    # 创建保存分割后文本的目录
    if not os.path.exists(SEGMENTED_DATA_DIR):
        os.makedirs(SEGMENTED_DATA_DIR)

    segmented_data = []

    # 处理小说
    for _, row in novel_data.iterrows():
        series = row['series']
        content = row['content']
        file = row['file']

        # 分割文本
        segments = split_text_into_segments(content, num_segments)

        # 保存每个分割部分
        for i, seg in enumerate(segments):
            seg_filename = f"{series} 小说{i + 1}.txt"
            seg_path = os.path.join(SEGMENTED_DATA_DIR, seg_filename)

            with open(seg_path, 'w', encoding='utf-8') as f:
                f.write(seg)

            # 添加到数据集
            segmented_data.append({
                'file': seg_filename,
                'content': seg,
                'category': '小说',
                'series': series,
                'segment': i + 1
            })

    # 处理剧本
    for _, row in script_data.iterrows():
        series = row['series']
        content = row['content']
        file = row['file']

        # 分割文本
        segments = split_text_into_segments(content, num_segments)

        # 保存每个分割部分
        for i, seg in enumerate(segments):
            seg_filename = f"{series} 剧本{i + 1}.txt"
            seg_path = os.path.join(SEGMENTED_DATA_DIR, seg_filename)

            with open(seg_path, 'w', encoding='utf-8') as f:
                f.write(seg)

            # 添加到数据集
            segmented_data.append({
                'file': seg_filename,
                'content': seg,
                'category': '剧本',
                'series': series,
                'segment': i + 1
            })

    print(f"文本分割完成，共生成 {len(segmented_data)} 个片段")
    return pd.DataFrame(segmented_data)


def split_text_into_segments(text, num_segments):
    """将文本平均分割为指定数量的部分"""
    if not text:
        return []

    # 按段落分割
    paragraphs = [p.strip() for p in text.split('\n') if p.strip()]

    if not paragraphs:
        return []

    # 如果段落数量不足，尝试按句子分割
    if len(paragraphs) < num_segments:
        sentences = re.split(r'[。！？\.\?!?]', text)
        sentences = [s.strip() for s in sentences if s.strip()]

        if len(sentences) >= num_segments:
            paragraphs = sentences
        else:
            # 如果句子数量还是不足，尝试按固定长度分割
            segment_length = max(1, len(text) // num_segments)
            return [text[i:i + segment_length] for i in range(0, len(text), segment_length)]

    # 按段落分割
    segments = []
    avg_paragraphs_per_segment = len(paragraphs) / num_segments

    for i in range(num_segments):
        start_idx = int(round(i * avg_paragraphs_per_segment))
        end_idx = int(round((i + 1) * avg_paragraphs_per_segment))

        # 确保至少有一个段落
        if start_idx >= len(paragraphs):
            start_idx = len(paragraphs) - 1

        if end_idx > len(paragraphs):
            end_idx = len(paragraphs)

        if start_idx >= end_idx:
            if start_idx > 0:
                start_idx -= 1
            else:
                break

        segment = "\n".join(paragraphs[start_idx:end_idx])
        segments.append(segment)

    return segments


# ------------------------
# 情感分析
# ------------------------
def analyze_sentiment(text):
    """使用SnowNLP进行情感分析，返回0-1之间的情感值"""
    if not text or len(text) < 20:  # 确保文本长度足够
        return 0.5  # 文本过短时返回中性值

    try:
        return SnowNLP(text).sentiments
    except Exception as e:
        print(f"情感分析失败: {str(e)}")
        return 0.5  # 出错时返回中性值


def compare_sentiments(novel_data, script_data, series_name=None):
    """对比小说和剧本的情感强度"""
    novel_sentiments = []
    script_sentiments = []

    # 加载停用词
    stopwords = load_stopwords(STOPWORDS_FILE)

    # 筛选特定剧集的数据
    if series_name:
        novel_data = novel_data[novel_data['series'] == series_name]
        script_data = script_data[script_data['series'] == series_name]

    # 小说情感分析
    for _, row in novel_data.iterrows():
        # 预处理文本
        processed_text = preprocess_text(row['content'], stopwords)
        if not processed_text:
            continue

        # 分段分析（每500个字符一段）
        segments = [processed_text[i:i + 500] for i in range(0, len(processed_text), 500)]
        for seg in segments:
            if len(seg) > 30:  # 确保段落有足够内容
                score = analyze_sentiment(seg)
                novel_sentiments.append({
                    'text': seg,
                    'sentiment': score,
                    'source': row['file']
                })

    # 剧本情感分析
    for _, row in script_data.iterrows():
        processed_text = preprocess_text(row['content'], stopwords)
        if not processed_text:
            continue

        segments = [processed_text[i:i + 500] for i in range(0, len(processed_text), 500)]
        for seg in segments:
            if len(seg) > 30:
                score = analyze_sentiment(seg)
                script_sentiments.append({
                    'text': seg,
                    'sentiment': score,
                    'source': row['file']
                })

    # 转换为DataFrame
    novel_sent_df = pd.DataFrame(novel_sentiments)
    script_sent_df = pd.DataFrame(script_sentiments)

    # 检查是否有情感数据
    if novel_sent_df.empty:
        print(f"警告: {series_name if series_name else '全部'} 小说没有有效的情感数据")
        novel_sent_df = pd.DataFrame({'sentiment': [0.5]})

    if script_sent_df.empty:
        print(f"警告: {series_name if series_name else '全部'} 剧本没有有效的情感数据")
        script_sent_df = pd.DataFrame({'sentiment': [0.5]})

    # 计算平均情感强度
    avg_novel_sent = novel_sent_df['sentiment'].mean()
    avg_script_sent = script_sent_df['sentiment'].mean()

    # 情感强度对比
    sentiment_comparison = {
        '小说平均情感': avg_novel_sent,
        '剧本平均情感': avg_script_sent,
        '情感差异': avg_script_sent - avg_novel_sent,
        '情感倾向': '积极' if avg_script_sent > 0.5 else '消极' if avg_script_sent < 0.5 else '中性',
        'series': series_name
    }

    return sentiment_comparison, novel_sent_df, script_sent_df


# ------------------------
# 文本特征提取与模型训练
# ------------------------
def extract_features(series_name, use_segmented=True):
    """提取指定剧集的文本特征（使用分割后数据作为样本）"""
    if use_segmented and os.path.exists(SEGMENTED_DATA_DIR):
        all_data = load_data(SEGMENTED_DATA_DIR)
        target_data = all_data[all_data['series'] == series_name].copy()
    else:
        print("错误: 未找到分割后数据或参数设置错误")
        return None, None, None, None

    # 数据检查
    if target_data.empty:
        print(f"警告: 剧集 {series_name} 无分割后数据")
        return None, None, None, None

    if len(target_data['category'].unique()) < 2:
        print(f"警告: 剧集 {series_name} 缺少类别数据")
        return None, None, None, None

    # 预处理文本
    stopwords = load_stopwords(STOPWORDS_FILE)
    target_data['processed_text'] = target_data['content'].apply(
        lambda x: preprocess_text(x, stopwords) if isinstance(x, str) else ""
    )
    target_data = target_data[target_data['processed_text'].str.strip() != ""]

    if target_data.empty:
        print(f"警告: 剧集 {series_name} 无有效文本数据")
        return None, None, None, None

    # 特征提取
    vectorizer = TfidfVectorizer(max_features=500, ngram_range=(1, 1), min_df=2)
    X = vectorizer.fit_transform(target_data['processed_text'])
    y = target_data['category']

    print(f"成功为 {series_name} 提取 {X.shape[0]} 个样本特征")
    print(f"{series_name} 类别分布:")
    print(y.value_counts())

    return X, y, vectorizer, target_data


def train_model(X, y, series_name):
    """训练分类模型并严格评估性能"""
    if X is None or y is None:
        print(f"错误: {series_name} 特征数据为空")
        return None, None, None, None

    model = LogisticRegression(max_iter=1000, penalty='l2', C=0.1)
    classes = np.unique(y)
    n_samples, n_classes = len(y), len(classes)

    # 检查类别分布
    if n_classes < 2:
        print(f"错误: {series_name} 只有{classes[0]}类别，无法分类")
        return None, None, None, None

    class_counts = pd.Series(y).value_counts()
    if (class_counts < 2).any():
        print(f"警告: {series_name} 存在类别样本数<2: {class_counts}")

    # 使用StratifiedKFold而非LeaveOneOut
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    # 分割训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42, stratify=y
    )

    # 训练模型
    model.fit(X_train, y_train)

    # 在测试集上评估
    y_pred = model.predict(X_test)
    test_f1 = f1_score(y_test, y_pred, average='weighted')

    # 同时计算交叉验证分数
    try:
        cv_f1_scores = cross_val_score(
            model, X, y, cv=cv, scoring='f1_weighted', n_jobs=-1
        )
    except Exception as e:
        print(f"交叉验证失败: {str(e)}")
        cv_f1_scores = np.array([test_f1])

    # 检查F1值合理性
    avg_cv_f1 = cv_f1_scores.mean()
    if avg_cv_f1 < 0.5:
        print(f"警告: {series_name} 交叉验证F1分数{avg_cv_f1:.2f}低于0.5，可能存在数据问题")
    elif avg_cv_f1 > 0.95:
        print(f"注意: {series_name} 交叉验证F1分数{avg_cv_f1:.2f}异常高，可能过拟合")

    # 生成混淆矩阵
    cm = confusion_matrix(y_test, y_pred)

    print(f"{series_name} 测试集F1分数: {test_f1:.4f}")
    print(f"{series_name} 交叉验证F1分数: {avg_cv_f1:.4f}")

    return model, cv_f1_scores, cm, y_pred, test_f1


# ------------------------
# 主题建模相关函数
# ------------------------
def fit_lda_model(texts, n_topics=3, max_features=3000):
    """训练LDA模型并返回主题-词分布（优化版）"""
    stopwords = load_stopwords(STOPWORDS_FILE)
    tf_vectorizer = CountVectorizer(
        max_features=max_features,
        ngram_range=(1, 2),  # 支持双字词
        stop_words=stopwords,
        min_df=2  # 过滤低频词
    )
    tf = tf_vectorizer.fit_transform(texts)

    lda = LatentDirichletAllocation(
        n_components=n_topics,
        random_state=42,
        max_iter=1000,
        learning_method='online'
    )
    lda.fit(tf)

    return lda, tf_vectorizer, tf


def get_top_words(lda, vectorizer, n_top_words=15):
    """获取每个主题的前n个关键词（优化关键词提取）"""
    feature_names = vectorizer.get_feature_names_out()
    top_words = []
    for topic_idx, topic in enumerate(lda.components_):
        # 排除单字关键词
        top_words_idx = [i for i in topic.argsort()[:-n_top_words - 1:-1] if len(feature_names[i]) > 1]
        top_words.append([feature_names[i] for i in top_words_idx])
    return top_words


def assign_document_topics(lda, tf, documents):
    """为每个文档分配主题（取概率最大的主题）"""
    topic_dist = lda.transform(tf)
    document_topics = []
    for i, doc in enumerate(documents):
        topic_idx = np.argmax(topic_dist[i])
        topic_prob = topic_dist[i][topic_idx]
        document_topics.append({
            'document': doc['file'],
            'topic': f"主题{topic_idx + 1}",
            'probability': topic_prob,
            'series': doc['series'],
            'category': doc['category']
        })
    return pd.DataFrame(document_topics)


# ------------------------
# 可视化分析
# ------------------------
def save_cv_results(f1_scores, series_name=None):
    """保存交叉验证结果图"""
    plt.figure(figsize=(10, 6))

    if len(f1_scores) > 1:
        plt.plot(range(1, len(f1_scores) + 1), f1_scores, marker='o', linestyle='-')
        plt.axhline(y=np.mean(f1_scores), color='r', linestyle='--', label=f'平均 F1: {np.mean(f1_scores):.4f}')
        plt.xlabel('折叠')
        plt.xticks(range(1, len(f1_scores) + 1))
    else:
        plt.axhline(y=f1_scores[0], color='r', linestyle='--', label=f'F1 分数: {f1_scores[0]:.4f}')
        plt.text(0.5, f1_scores[0] + 0.02, f'F1 = {f1_scores[0]:.4f}', ha='center')
        plt.ylim(-0.1, 1.1)

    plt.title(f"{series_name if series_name else '全部'} 交叉验证 F1 分数")
    plt.ylabel('F1 分数')
    plt.ylim(0, 1)
    plt.legend()
    plt.grid(True)

    filename = f"cv_results_{series_name if series_name else 'all'}.png"
    plt.savefig(os.path.join(FIGURES_DIR, filename))
    plt.close()


def save_confusion_matrix(cm, classes, series_name=None):
    """保存混淆矩阵图"""
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=classes, yticklabels=classes)
    plt.title(f"{series_name if series_name else '全部'} 混淆矩阵")
    plt.xlabel('预测类别')
    plt.ylabel('实际类别')

    filename = f"confusion_matrix_{series_name if series_name else 'all'}.png"
    plt.savefig(os.path.join(FIGURES_DIR, filename))
    plt.close()


def plot_sentiment_distribution(novel_sent_df, script_sent_df, series_name=None):
    """绘制情感分布直方图"""
    plt.figure(figsize=(12, 6))

    plt.subplot(1, 2, 1)
    plt.hist(novel_sent_df['sentiment'], bins=20, alpha=0.7, color='blue')
    plt.title(f"{series_name if series_name else '全部'} 小说情感分布")
    plt.xlabel('情感值')
    plt.ylabel('频次')
    plt.xlim(0, 1)

    plt.subplot(1, 2, 2)
    plt.hist(script_sent_df['sentiment'], bins=20, alpha=0.7, color='red')
    plt.title(f"{series_name if series_name else '全部'} 剧本情感分布")
    plt.xlabel('情感值')
    plt.ylabel('频次')
    plt.xlim(0, 1)

    plt.tight_layout()

    filename = f"sentiment_distribution_{series_name if series_name else 'all'}.png"
    plt.savefig(os.path.join(FIGURES_DIR, filename))
    plt.close()


def plot_common_words(novel_data, script_data, series_name=None, top_n=20):
    """分析并可视化小说和剧本中共同的高频词"""
    # 加载停用词
    stopwords = load_stopwords(STOPWORDS_FILE)

    # 筛选特定剧集的数据
    if series_name:
        novel_data = novel_data[novel_data['series'] == series_name]
        script_data = script_data[script_data['series'] == series_name]

    # 合并所有小说文本
    novel_text = " ".join(novel_data['content'].apply(lambda x: preprocess_text(x, stopwords)))
    novel_words = novel_text.split()

    # 合并所有剧本文本
    script_text = " ".join(script_data['content'].apply(lambda x: preprocess_text(x, stopwords)))
    script_words = script_text.split()

    # 计算词频
    novel_word_freq = pd.Series(novel_words).value_counts()
    script_word_freq = pd.Series(script_words).value_counts()

    # 找出共同高频词
    common_words = set(novel_word_freq.index[:top_n]) & set(script_word_freq.index[:top_n])

    if not common_words:
        print(f"警告: {series_name if series_name else '全部'} 小说和剧本中没有找到共同高频词")
        return None

    # 提取频率数据
    common_freq = []
    for word in common_words:
        common_freq.append({
            'word': word,
            'novel_freq': novel_word_freq[word],
            'script_freq': script_word_freq[word]
        })

    common_freq_df = pd.DataFrame(common_freq)

    # 计算频率差异
    common_freq_df['freq_diff'] = common_freq_df['script_freq'] - common_freq_df['novel_freq']
    common_freq_df['变化倾向'] = common_freq_df['freq_diff'].apply(
        lambda x: '增强' if x > 0 else ('减弱' if x < 0 else '不变')
    )

    # 绘制对比图
    plt.figure(figsize=(12, 8))
    x = np.arange(len(common_words))
    width = 0.35

    plt.bar(x - width / 2, common_freq_df['novel_freq'], width, label='小说')
    plt.bar(x + width / 2, common_freq_df['script_freq'], width, label='剧本')

    plt.xticks(x, common_freq_df['word'], rotation=45)
    plt.ylabel('词频')
    plt.title(f"{series_name if series_name else '全部'} 小说与剧本中共同高频词对比")
    plt.legend()
    plt.tight_layout()

    filename = f"common_words_{series_name if series_name else 'all'}.png"
    plt.savefig(os.path.join(FIGURES_DIR, filename))
    plt.close()

    return common_freq_df


def plot_wordcloud(text, title, filename):
    """生成词云图"""
    if not text or len(text.strip()) < 10:
        print(f"警告: 文本内容不足，无法生成{title}词云图")
        return

    wordcloud = WordCloud(
        font_path='simhei.ttf',  # 需要下载中文字体文件
        width=800, height=400,
        background_color='white',
        max_words=100,
        colormap='viridis'
    ).generate(text)

    plt.figure(figsize=(10, 6))
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.title(title)
    plt.axis('off')

    plt.savefig(os.path.join(FIGURES_DIR, filename))
    plt.close()


def plot_sentiment_comparison(sentiment_comparisons):
    """绘制所有剧集的情感对比图"""
    if not sentiment_comparisons:
        print("警告: 没有情感对比数据")
        return

    # 创建DataFrame
    df = pd.DataFrame(sentiment_comparisons)

    # 过滤掉没有名称的对比（整体对比）
    series_df = df[df['series'].notna()]

    if series_df.empty:
        print("警告: 没有剧集特定的情感对比数据")
        return

    # 绘制情感对比条形图
    plt.figure(figsize=(14, 8))

    x = np.arange(len(series_df))
    width = 0.35

    plt.bar(x - width / 2, series_df['小说平均情感'], width, label='小说')
    plt.bar(x + width / 2, series_df['剧本平均情感'], width, label='剧本')

    # 添加情感差异注释
    for i, (novel, script) in enumerate(zip(series_df['小说平均情感'], series_df['剧本平均情感'])):
        diff = script - novel
        plt.text(i, max(novel, script) + 0.02, f"{diff:+.4f}", ha='center', fontsize=10)

    plt.xticks(x, series_df['series'], rotation=45)
    plt.ylabel('情感值')
    plt.title('各剧集小说与剧本情感值对比')
    plt.ylim(0, 1)
    plt.legend()
    plt.tight_layout()

    plt.savefig(os.path.join(FIGURES_DIR, 'sentiment_comparison_all_series.png'))
    plt.close()


def plot_sentiment_matrix(sentiment_comparisons):
    """绘制情感矩阵图"""
    if not sentiment_comparisons:
        print("警告: 没有情感对比数据")
        return

    # 创建DataFrame
    df = pd.DataFrame(sentiment_comparisons)

    # 提取需要的数据
    matrix_data = df[['小说平均情感', '剧本平均情感', '情感差异']].copy()
    matrix_data.index = df['series'] if 'series' in df.columns else ['整体']

    # 绘制热力图
    plt.figure(figsize=(10, 8))
    sns.heatmap(matrix_data, annot=True, fmt='.4f', cmap='coolwarm', linewidths=.5)
    plt.title('情感分析矩阵')
    plt.tight_layout()

    plt.savefig(os.path.join(FIGURES_DIR, 'sentiment_matrix.png'))
    plt.close()


# ------------------------
# 主程序
# ------------------------
def main():
    print("小说与剧本文本分析系统启动...")

    # 创建保存图片的目录
    if not os.path.exists(FIGURES_DIR):
        print(f"创建目录: {FIGURES_DIR}")
        os.makedirs(FIGURES_DIR)

    # 检查数据目录
    for dir_path in [DATA_DIR, NOVEL_DIR, SCRIPT_DIR]:
        if not os.path.exists(dir_path):
            print(f"创建目录: {dir_path}")
            os.makedirs(dir_path)

    # 加载数据
    print("正在加载数据...")
    novel_data = load_data(NOVEL_DIR)
    script_data = load_data(SCRIPT_DIR)

    if novel_data.empty or script_data.empty:
        print("错误: 数据不足，无法继续分析")
        print("请确保 'data/novel' 和 'data/script' 目录下有文本文件")
        return

    print(f"已加载 {len(novel_data)} 部小说和 {len(script_data)} 部剧本")

    # 文本分割（确保每个文件至少分割成5段）
    segmented_data = segment_texts(novel_data, script_data, num_segments=max(5, len(novel_data) + len(script_data)))

    # 获取所有有效剧集
    all_series = list(set(segmented_data['series']))
    valid_series = []

    for series in all_series:
        series_data = segmented_data[segmented_data['series'] == series]

        novel_count = len(series_data[series_data['category'] == '小说'])
        script_count = len(series_data[series_data['category'] == '剧本'])

        if novel_count >= 2 and script_count >= 2:
            valid_series.append(series)
        else:
            print(f"警告: 剧集 {series} 样本不足（小说:{novel_count}, 剧本:{script_count}），将跳过")

    print(f"找到 {len(valid_series)} 个有效剧集进行分析")

    if not valid_series:
        print("错误: 没有找到符合条件的剧集")
        return

    # 主题建模参数（用户指定n_topics=3）
    n_topics = 3
    max_features = 3000  # 增加特征数捕捉更多关键词

    # 分析原著主题（小说类别）
    print("\n------------------------\n正在进行原著主题建模...")
    novel_data_filtered = novel_data[novel_data['category'] == '小说']
    novel_texts = novel_data_filtered['content'].apply(
        lambda x: preprocess_text(x, load_stopwords(STOPWORDS_FILE))).tolist()
    novel_lda, novel_vectorizer, novel_tf = fit_lda_model(novel_texts, n_topics, max_features)
    novel_top_words = get_top_words(novel_lda, novel_vectorizer)

    # 验证原著主题是否符合预期
    print("原著核心主题:")
    for i, words in enumerate(novel_top_words):
        print(
            f"主题 {i + 1} ({np.round(novel_lda.components_[i].sum() / novel_lda.components_.sum() * 100, 1)}%): {' '.join(words)}")

    # 分析剧本主题（剧本类别）
    print("\n------------------------\n正在进行剧本主题建模...")
    script_data_filtered = script_data[script_data['category'] == '剧本']
    script_texts = script_data_filtered['content'].apply(
        lambda x: preprocess_text(x, load_stopwords(STOPWORDS_FILE))).tolist()
    script_lda, script_vectorizer, script_tf = fit_lda_model(script_texts, n_topics, max_features)
    script_top_words = get_top_words(script_lda, script_vectorizer)

    # 验证剧本主题是否符合预期
    print("剧本核心主题:")
    for i, words in enumerate(script_top_words):
        print(
            f"主题 {i + 1} ({np.round(script_lda.components_[i].sum() / script_lda.components_.sum() * 100, 1)}%): {' '.join(words)}")

    # 为分割后的每个文档分配主题
    print("\n------------------------\n正在为分割文档分配主题...")
    segmented_data_processed = segmented_data.copy()
    segmented_data_processed['processed_text'] = segmented_data_processed['content'].apply(
        lambda x: preprocess_text(x, load_stopwords(STOPWORDS_FILE))
    )

    # 处理小说文档主题分配
    novel_segmented = segmented_data_processed[segmented_data_processed['category'] == '小说']
    novel_tf_segmented = novel_vectorizer.transform(novel_segmented['processed_text'])
    novel_document_topics = assign_document_topics(novel_lda, novel_tf_segmented, novel_segmented.to_dict('records'))

    # 处理剧本文档主题分配
    script_segmented = segmented_data_processed[segmented_data_processed['category'] == '剧本']
    script_tf_segmented = script_vectorizer.transform(script_segmented['processed_text'])
    script_document_topics = assign_document_topics(script_lda, script_tf_segmented,
                                                    script_segmented.to_dict('records'))

    # 合并主题分配结果
    all_document_topics = pd.concat([novel_document_topics, script_document_topics])

    # 输出主题分配结果（示例）
    print("\n分割文档主题分配示例:")
    print(all_document_topics[['document', 'series', 'category', 'topic', 'probability']].head())

    # 按剧集分析
    all_sentiment_comparisons = []
    all_test_f1_scores = {}

    for series in valid_series:
        print(f"\n------------------------\n分析剧集: {series}\n------------------------")

        # 情感分析
        sentiment_comparison, novel_sent_df, script_sent_df = compare_sentiments(novel_data, script_data, series)
        all_sentiment_comparisons.append(sentiment_comparison)

        # 特征提取与模型训练，使用分割后的数据
        X, y, vectorizer, _ = extract_features(series)

        # 模型训练
        if X is not None and y is not None:
            model, f1_scores, cm, y_pred, test_f1 = train_model(X, y, series)
            all_test_f1_scores[series] = test_f1
        else:
            print(f"警告: {series} 无法提取有效特征，跳过模型训练")
            continue

        # 可视化分析结果
        print(f"正在生成 {series} 的可视化结果...")

        # 1. 绘制情感分布直方图
        plot_sentiment_distribution(novel_sent_df, script_sent_df, series)

        # 2. 生成词云图
        stopwords = load_stopwords(STOPWORDS_FILE)
        series_novel_data = novel_data[novel_data['series'] == series]
        series_script_data = script_data[script_data['series'] == series]

        if not series_novel_data.empty:
            novel_text = " ".join(series_novel_data['content'].apply(lambda x: preprocess_text(x, stopwords)))
            plot_wordcloud(novel_text, f"{series} 小说高频词云图", f"novel_wordcloud_{series}.png")
        if not series_script_data.empty:
            script_text = " ".join(series_script_data['content'].apply(lambda x: preprocess_text(x, stopwords)))
            plot_wordcloud(script_text, f"{series} 剧本高频词云图", f"script_wordcloud_{series}.png")

        # 3. 分析并可视化共同高频词
        common_words_df = plot_common_words(novel_data, script_data, series)
        if common_words_df is not None and not common_words_df.empty:
            print(f"{series} 小说与剧本共同高频词分析:")
            print(common_words_df.sort_values('freq_diff', ascending=False))

        # 4. 保存交叉验证结果
        save_cv_results(f1_scores, series)

        # 5. 保存混淆矩阵
        save_confusion_matrix(cm, np.unique(y), series)

    # 整体分析
    print("\n------------------------\n正在进行整体分析...")

    # 合并所有有效剧集的数据
    if valid_series:
        all_valid_data = pd.DataFrame()
        for series in valid_series:
            series_data = segmented_data[segmented_data['series'] == series]
            all_valid_data = pd.concat([all_valid_data, series_data])

        print(f"整体分析使用 {len(all_valid_data)} 个样本")

        # 整体情感分析
        overall_sentiment, overall_novel_sent, overall_script_sent = compare_sentiments(
            novel_data, script_data
        )
        all_sentiment_comparisons.append(overall_sentiment)

        # 整体特征提取与模型训练
        X, y, vectorizer, _ = extract_features("all_series_combined", use_segmented=True)

        # 如果标准方法失败，尝试使用合并的有效数据
        if X is None or y is None:
            print("警告: 剧集 all_series_combined 无分割后数据")
            print("警告: 使用合并所有有效剧集的数据进行整体分析")
            if not all_valid_data.empty:
                stopwords = load_stopwords(STOPWORDS_FILE)
                all_valid_data['processed_text'] = all_valid_data['content'].apply(
                    lambda x: preprocess_text(x, stopwords) if isinstance(x, str) else ""
                )
                all_valid_data = all_valid_data[all_valid_data['processed_text'].str.strip() != ""]

                if not all_valid_data.empty:
                    vectorizer = TfidfVectorizer(max_features=500, ngram_range=(1, 1), min_df=2)
                    X = vectorizer.fit_transform(all_valid_data['processed_text'])
                    y = all_valid_data['category']

                    print(f"成功为整体分析提取 {X.shape[0]} 个样本特征")
                    print("整体分析类别分布:")
                    print(y.value_counts())
                else:
                    print("错误: 整体分析无有效数据，跳过模型训练")
                    X, y = None, None

        # 执行整体模型训练（如果有有效数据）
        if X is not None and y is not None:
            model, f1_scores, cm, y_pred, test_f1 = train_model(X, y, "整体")
            all_test_f1_scores["整体"] = test_f1
        else:
            print("警告: 整体分析无法提取有效特征，跳过模型训练")

        # 整体可视化
        print("正在生成整体可视化结果...")

        # 情感分布直方图
        plot_sentiment_distribution(overall_novel_sent, overall_script_sent, "整体")

        # 词云图
        stopwords = load_stopwords(STOPWORDS_FILE)
        if not novel_data.empty:
            all_novel_text = " ".join(novel_data['content'].apply(lambda x: preprocess_text(x, stopwords)))
            plot_wordcloud(all_novel_text, "全部小说高频词云图", "novel_wordcloud_all.png")
        if not script_data.empty:
            all_script_text = " ".join(script_data['content'].apply(lambda x: preprocess_text(x, stopwords)))
            plot_wordcloud(all_script_text, "全部剧本高频词云图", "script_wordcloud_all.png")

        # 共同高频词对比
        if not novel_data.empty and not script_data.empty:
            common_words_df = plot_common_words(novel_data, script_data)
            if common_words_df is not None and not common_words_df.empty:
                print("整体小说与剧本共同高频词分析:")
                print(common_words_df.sort_values('freq_diff', ascending=False))

        # 情感对比图和矩阵图
        plot_sentiment_comparison(all_sentiment_comparisons)
        plot_sentiment_matrix(all_sentiment_comparisons)

        # 保存交叉验证和混淆矩阵（如果有模型训练结果）
        if 'f1_scores' in locals() and f1_scores is not None:
            save_cv_results(f1_scores, "整体")
        if 'cm' in locals() and cm is not None:
            save_confusion_matrix(cm, np.unique(y), "整体")

    # 保存主题分配结果到文件
    all_document_topics.to_csv(os.path.join(FIGURES_DIR, 'document_topics.csv'), index=False)
    print(f"\n所有文档主题分配结果已保存至 {FIGURES_DIR}/document_topics.csv")

    # 输出所有剧集和整体的F1分数
    print("\n各剧集及整体分类模型F1分数:")
    for series, f1 in all_test_f1_scores.items():
        print(f"{series}: {f1:.4f}")

    print(f"\n分析完成！所有结果图片已保存到 {FIGURES_DIR} 文件夹中。")


if __name__ == "__main__":
    main()